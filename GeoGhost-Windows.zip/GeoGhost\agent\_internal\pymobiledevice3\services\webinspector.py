import asyncio
import contextlib
import json
import time
import uuid
from collections import deque
from collections.abc import Coroutine
from dataclasses import dataclass, fields
from enum import Enum
from typing import Any, Callable, Optional, Union

from pymobiledevice3.exceptions import (
    ConnectionTerminatedError,
    LaunchingApplicationError,
    RemoteAutomationNotEnabledError,
    WebInspectorNotEnabledError,
)
from pymobiledevice3.lockdown_service_provider import LockdownServiceProvider
from pymobiledevice3.services.lockdown_service import LockdownService
from pymobiledevice3.services.notification_proxy import NotificationProxyService
from pymobiledevice3.services.web_protocol.automation_session import AutomationSession
from pymobiledevice3.services.web_protocol.inspector_session import InspectorSession
from pymobiledevice3.services.web_protocol.session_protocol import SessionProtocol

SAFARI = "com.apple.mobilesafari"
WEBINSPECTORD_DISABLED_NOTIFICATION = "com.apple.webinspectord.disabled"
# How long webinspectord may keep refusing a session before it is taken to mean Web Inspector is
# disabled, and how long to wait between attempts (see WebinspectorService._handshake).
HANDSHAKE_RETRY_TIMEOUT = 20
HANDSHAKE_RETRY_INTERVAL = 1


def key_to_pid(key: str) -> int:
    return int(key.split(":")[1])


def make_target_id(app_id: str, page_id: str) -> str:
    """Build an identifier addressing one page of one application.

    `webinspectord` numbers pages per application, so a page identifier alone is ambiguous as soon
    as more than one application is inspectable - and it always is with JSContext debuggables,
    which are page 1 of every process hosting one. Qualifying it with the application identifier
    keeps the identifiers the CDP bridge hands out unique. Resolve one with
    `WebinspectorService.find_page_id`.

    :param app_id: The owning application's identifier (`WIRApplicationIdentifierKey`).
    :param page_id: The page's identifier within that application.
    """
    return f"{app_id}:{page_id}"


class WirTypes(Enum):
    AUTOMATION = "WIRTypeAutomation"
    ITML = "WIRTypeITML"
    JAVASCRIPT = "WIRTypeJavaScript"
    PAGE = "WIRTypePage"
    SERVICE_WORKER = "WIRTypeServiceWorker"
    WEB = "WIRTypeWeb"
    WEB_PAGE = "WIRTypeWebPage"
    AUTOMATICALLY_PAUSE = "WIRAutomaticallyPause"


class AutomationAvailability(Enum):
    NOT_AVAILABLE = "WIRAutomationAvailabilityNotAvailable"
    AVAILABLE = "WIRAutomationAvailabilityAvailable"
    UNKNOWN = "WIRAutomationAvailabilityUnknown"


@dataclass
class Page:
    """A single inspectable target (web page, automation target, etc.) reported by an application."""

    id_: int
    type_: WirTypes
    web_url: str = ""
    web_title: str = ""
    # The Web Inspector connection currently debugging this page, when there is one. WebKit serves
    # a single inspector session per debuggable, so a page listed with somebody else's connection
    # identifier cannot be attached to until they let go. Reported for every debuggable, JSContexts
    # included; automation targets carry theirs in `automation_connection_id`.
    web_connection_id: str = ""
    automation_is_paired_key: bool = False
    automation_name: str = ""
    automation_version: str = ""
    automation_session_id: str = ""
    automation_connection_id: str = ""

    @classmethod
    def from_page_dictionary(cls, page_dict: dict[str, Any]) -> "Page":
        p = cls(page_dict["WIRPageIdentifierKey"], WirTypes(page_dict["WIRTypeKey"]))
        if p.type_ in (WirTypes.WEB, WirTypes.WEB_PAGE):
            p.web_title = page_dict["WIRTitleKey"]
            p.web_url = page_dict["WIRURLKey"]
        if p.type_ == WirTypes.JAVASCRIPT:
            # A JSContext debuggable is listed with a title (its name, "JSContext" by default) but
            # no URL - there is no document behind it.
            p.web_title = page_dict.get("WIRTitleKey", "")
        if p.type_ != WirTypes.AUTOMATION:
            p.web_connection_id = page_dict.get("WIRConnectionIdentifierKey", "")
        if p.type_ == WirTypes.AUTOMATION:
            p.automation_is_paired_key = page_dict["WIRAutomationTargetIsPairedKey"]
            p.automation_name = page_dict["WIRAutomationTargetNameKey"]
            p.automation_version = page_dict["WIRAutomationTargetVersionKey"]
            p.automation_session_id = page_dict["WIRSessionIdentifierKey"]
            if "WIRConnectionIdentifierKey" in page_dict:
                p.automation_connection_id = page_dict["WIRConnectionIdentifierKey"]
        return p

    def update(self, page_dict: dict[str, Any]):
        new_p = self.from_page_dictionary(page_dict)
        for field in fields(self):
            setattr(self, field.name, getattr(new_p, field.name))

    def __str__(self):
        return f"id: {self.id_}, title: {self.web_title}, url: {self.web_url}"


@dataclass
class Application:
    """An application reported by `webinspectord` as available for web inspection or automation."""

    id_: str
    bundle: str
    pid: int
    name: str
    availability: AutomationAvailability
    active: int
    proxy: bool
    ready: bool
    host: str = ""
    # The application's icon as PNG bytes (`WIRApplicationIconKey`); processes without one are
    # sent a generic placeholder by the device.
    icon: bytes = b""

    @classmethod
    def from_application_dictionary(cls, app_dict: dict[str, Any]) -> "Application":
        return cls(
            app_dict["WIRApplicationIdentifierKey"],
            app_dict["WIRApplicationBundleIdentifierKey"],
            key_to_pid(app_dict["WIRApplicationIdentifierKey"]),
            app_dict["WIRApplicationNameKey"],
            AutomationAvailability(app_dict.get("WIRAutomationAvailabilityKey", AutomationAvailability.UNKNOWN.value)),
            app_dict["WIRIsApplicationActiveKey"],
            app_dict["WIRIsApplicationProxyKey"],
            app_dict["WIRIsApplicationReadyKey"],
            app_dict.get("WIRHostApplicationIdentifierKey", ""),
            app_dict.get("WIRApplicationIconKey", b""),
        )


@dataclass
class ApplicationPage:
    application: Application
    page: Page

    def __str__(self) -> str:
        return f"<{self.application.name}({self.application.pid}) TYPE:{self.page.type_.value} URL:{self.page.web_url}>"


@dataclass(frozen=True)
class AutomaticInspectionCandidate:
    """A debuggable an application just created and is holding, waiting for a debugger.

    Offered by `webinspectord` (as `_rpc_reportAutomaticInspectionCandidate:`) to every connection
    that enabled automatic inspection, one connection at a time. The application blocks the thread
    creating the debuggable until the candidate is either accepted - a socket setup for the page,
    followed by the frontend's `Inspector.initialized` - or rejected, and gives up on its own
    after ten seconds. WebKit only offers JSContexts and service workers; web pages never block.
    """

    app_id: str
    page_id: int
    session_id: str


class WebinspectorService(LockdownService):
    """Client for the `com.apple.webinspector` service (`webinspectord`).

    Drives Safari/WebKit remote inspection and WebDriver automation: enumerates inspectable
    applications and their pages, launches applications, and forwards the inspector/automation
    socket traffic used to build `InspectorSession` and `AutomationSession` objects.

    The service maintains a background receive task that dispatches incoming RPC notifications
    and keeps the cached application/page state up to date. Call `connect` before issuing any
    requests and `close` when done.
    """

    SERVICE_NAME = "com.apple.webinspector"
    RSD_SERVICE_NAME = "com.apple.webinspector.shim.remote"

    def __init__(self, lockdown: LockdownServiceProvider) -> None:
        super().__init__(lockdown)
        self.connection_id = str(uuid.uuid4()).upper()
        self.state: Optional[str] = None
        self.connected_application: dict[str, Application] = {}
        self.application_pages: dict[str, Any] = {}
        self.wir_message_results: dict[str, Any] = {}
        # Optional observer of every inspector-protocol message crossing the page sockets, as
        # (direction, session id, message); the CDP bridge's --trace recorder plugs in here.
        self.trace: Optional[Callable[[str, str, Any], None]] = None
        self.wir_events: dict[str, deque[Any]] = {}
        self.receive_handlers = {
            "_rpc_reportCurrentState:": self._handle_report_current_state,
            "_rpc_reportConnectedApplicationList:": self._handle_report_connected_application_list,
            "_rpc_reportConnectedDriverList:": self._handle_report_connected_driver_list,
            "_rpc_applicationSentListing:": self._handle_application_sent_listing,
            "_rpc_applicationUpdated:": self._handle_application_updated,
            "_rpc_applicationConnected:": self._handle_application_connected,
            "_rpc_applicationSentData:": self._handle_application_sent_data,
            "_rpc_applicationDisconnected:": self._handle_application_disconnected,
            "_rpc_reportAutomaticInspectionCandidate:": self._handle_report_automatic_inspection_candidate,
        }
        self._recv_task: Optional[asyncio.Task[None]] = None
        # Set once the device's Web Inspector connection drops (a restart, a cable pull). The
        # listing endpoints then serve what was last known instead of raising per request; the
        # bridge stays up rather than spewing a traceback on every landing-page poll.
        self._connection_lost = False
        # Called once when the connection drops, so the caller can act on it - the CDP bridge
        # raises a device-disconnected error so pymobiledevice3's --reconnect can retry the command.
        self.on_connection_lost: Optional[Callable[[], None]] = None
        # Queues handed out by subscribe_*: the receive task publishes into them without waiting,
        # so a subscriber that reacts by talking to the device (whose answers arrive through this
        # same receive task) never deadlocks it.
        self._candidate_subscribers: list[asyncio.Queue[AutomaticInspectionCandidate]] = []
        self._listing_subscribers: list[asyncio.Queue[str]] = []

    async def connect(self) -> None:
        """Establish the WebInspector session and start the background receive task.

        Performs the initial handshake (reporting this client's identifier and processing the
        first reply) while watching for a disabled notification, then spawns the task that keeps
        consuming incoming messages. Safe to call repeatedly; subsequent calls are a no-op once
        the receive task is running.

        :raises WebInspectorNotEnabledError: Web Inspector is disabled on the device.
        """
        if self._recv_task is not None:
            return

        await self._connect_or_raise_disabled()
        self._recv_task = asyncio.create_task(self._receiving_task())

    @property
    def is_connected(self) -> bool:
        """Whether the device's Web Inspector connection is still up."""
        return not self._connection_lost

    @staticmethod
    def _is_connection_lost(error: BaseException) -> bool:
        return isinstance(
            error, (ConnectionError, ConnectionTerminatedError, asyncio.IncompleteReadError, EOFError, OSError)
        )

    def _note_connection_lost(self, error: BaseException) -> None:
        if not self._connection_lost:
            self._connection_lost = True
            self.logger.warning(f"Web Inspector connection to the device lost ({type(error).__name__})")
            if self.on_connection_lost is not None:
                self.on_connection_lost()

    async def close(self):
        """Cancel the background receive task and close the underlying service connection."""
        if self._recv_task is not None:
            self._recv_task.cancel()
            with contextlib.suppress(asyncio.CancelledError, ConnectionTerminatedError):
                await self._recv_task
            self._recv_task = None
        await super().close()

    async def _recv_message(self):
        while True:
            try:
                return await self.service.recv_plist()
            except asyncio.IncompleteReadError:
                await asyncio.sleep(0)

    async def _wait_for_disabled_notification(self, notification_proxy: NotificationProxyService) -> None:
        async for event in notification_proxy.receive_notification():
            if event.get("Name") == WEBINSPECTORD_DISABLED_NOTIFICATION:
                raise WebInspectorNotEnabledError

    async def _connect_or_raise_disabled(self) -> None:
        async with NotificationProxyService(self.lockdown) as notification_proxy:
            await notification_proxy.notify_register_dispatch(WEBINSPECTORD_DISABLED_NOTIFICATION)
            disabled_task = asyncio.create_task(self._wait_for_disabled_notification(notification_proxy))
            try:
                await self._handshake(disabled_task)
            finally:
                disabled_task.cancel()
                with contextlib.suppress(asyncio.CancelledError):
                    await disabled_task

    async def _handshake(self, disabled_task: asyncio.Task[None]) -> None:
        """Run the WebInspector handshake, retrying while webinspectord keeps refusing it.

        webinspectord refuses a session by terminating the connection - accepting it and never
        completing the TLS handshake, or closing it right after - and does so for three reasons
        that look identical from here:

        * Web Inspector is disabled on the device.
        * The gate it puts on consecutive sessions has not elapsed: a new session is admitted only
          about ten seconds after the previous one started. DEFAULT_SSL_HANDSHAKE_TIMEOUT now
          outlasts that wait, so a reattach right after a session ended - restarting the CDP bridge,
          or opening an automation session once inspection is done - normally just waits it out.
        * It is not up yet because the device is still booting. `--reconnect` re-runs a command the
          moment lockdownd answers again, which is seconds before webinspectord serves anything.

        Only the first is permanent, so keep trying until the deadline and report the refusal as
        Web Inspector being disabled only if it outlives it. A device that goes away mid-handshake
        is reported as the disconnect it is, so that a caller which retries on a disconnect (the
        CDP bridge under `--reconnect`) does. `disabled_task`, the device's own disabled
        notification, ends the wait immediately.
        """
        deadline = time.monotonic() + HANDSHAKE_RETRY_TIMEOUT
        while True:
            try:
                await self._await_or_raise_disabled(super().connect(), disabled_task)
                await self._await_or_raise_disabled(self._report_identifier(), disabled_task)
                await self._handle_recv(await self._await_or_raise_disabled(self._recv_message(), disabled_task))
            except ConnectionTerminatedError as e:
                if not await self._device_answers():
                    raise
                if time.monotonic() >= deadline:
                    raise WebInspectorNotEnabledError from e
            else:
                return
            self.logger.debug("webinspectord refused the session; retrying")
            # Drop the refused connection so the next attempt starts a session of its own.
            await self.close()
            await asyncio.sleep(HANDSHAKE_RETRY_INTERVAL)

    async def _await_or_raise_disabled(self, coro: Coroutine[Any, Any, Any], disabled_task: asyncio.Task[None]):
        task = asyncio.create_task(coro)
        done, _ = await asyncio.wait(
            {task, disabled_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if disabled_task in done:
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await task
            await disabled_task
        return await task

    async def _device_answers(self) -> bool:
        """Whether lockdownd still answers.

        A device that went away and one that refused the session both terminate the WebInspector
        connection abruptly; only the one that is still there answers.
        """
        try:
            await self.lockdown.get_date()
        except Exception:
            return False
        return True

    async def _receiving_task(self):
        try:
            while True:
                await self._handle_recv(await self._recv_message())
        except asyncio.CancelledError:
            raise
        except BaseException as error:
            if self._is_connection_lost(error):
                self._note_connection_lost(error)
                return
            raise

    async def automation_session(self, app: Application) -> AutomationSession:
        """Start a WebDriver automation session against an application.

        Requests a new automation session, waits for the corresponding automation page to appear,
        sets up its forwarding socket, and waits until the page reports an automation connection id.

        :param app: The application to automate.
        :returns: A connected automation session.
        :raises RemoteAutomationNotEnabledError: Remote automation is not available on the device.
        """
        if self.state == "WIRAutomationAvailabilityNotAvailable":
            raise RemoteAutomationNotEnabledError()
        session_id = str(uuid.uuid4()).upper()
        await self._forward_automation_session_request(session_id, app.id_)
        await self._forward_get_listing(app.id_)
        page = await self._wait_for_page(session_id)
        await self._forward_socket_setup(session_id, app.id_, page.id_)
        await self._forward_get_listing(app.id_)
        while not page.automation_connection_id:
            await asyncio.sleep(0)
        return AutomationSession(SessionProtocol(self, session_id, app, page))

    async def inspector_session(self, app: Application, page: Page) -> InspectorSession:
        """Open a Web Inspector session against a specific page of an application.

        :param app: The application owning the page.
        :param page: The page to inspect.
        :returns: A connected inspector session. For non-JavaScript pages the session waits for the
            inspection target before returning.
        """
        session_id = str(uuid.uuid4()).upper()
        return await InspectorSession.create(
            SessionProtocol(self, session_id, app, page, method_prefix=""),
            wait_target=page.type_ != WirTypes.JAVASCRIPT,
        )

    async def get_open_pages(self) -> dict[str, Any]:
        """Request and return the currently open pages of all connected applications.

        :returns: A mapping of application name to the collection of its `Page` objects, including
            only applications that currently report at least one page.
        """
        apps: dict[str, Any] = {}
        # One failing listing (or a lost connection) must not break the whole answer; serve what
        # was last reported instead.
        await asyncio.gather(
            *[self._forward_get_listing(app) for app in self.connected_application], return_exceptions=True
        )
        for app in self.connected_application:
            if self.application_pages.get(app, False):
                apps[self.connected_application[app].name] = self.application_pages[app].values()
        return apps

    async def get_open_application_pages(self, timeout: float) -> list[ApplicationPage]:
        """Enumerate all inspectable application/page pairs across connected applications.

        Queries the connected applications and then waits for `webinspectord` to report their
        listings before collecting the results.

        :param timeout: Seconds to wait for the device to reply with the application listings.
        :returns: A list of `ApplicationPage` pairs, one per reported page.
        """
        # Query all connected applications
        await self._get_connected_applications()

        # Give some time for `webinspectord` to reply with all inspectable applications
        await asyncio.sleep(timeout)

        result: list[ApplicationPage] = []
        for app in self.connected_application:
            if self.application_pages.get(app, False):
                for page in self.application_pages[app].values():
                    result.append(ApplicationPage(self.connected_application[app], page))
        return result

    async def open_app(self, bundle: str, timeout: Union[float, int] = 3) -> Application:
        """Launch an application by bundle identifier and wait for it to connect.

        :param bundle: The bundle identifier of the application to launch.
        :param timeout: Seconds to wait for the application to appear as connected.
        :returns: The connected application.
        :raises LaunchingApplicationError: The application did not connect within the timeout.
        """
        await self._request_application_launch(bundle)
        await self.get_open_pages()
        try:
            return await asyncio.wait_for(self._wait_for_application(bundle), timeout)
        except TimeoutError as e:
            raise LaunchingApplicationError() from e

    async def send_socket_data(self, session_id: str, app_id: str, page_id: int, data: dict[str, Any]):
        """Forward an inspector/automation protocol message to a page's socket.

        :param session_id: The session identifier owning the socket.
        :param app_id: The target application identifier.
        :param page_id: The target page identifier.
        :param data: The protocol message to send; serialized to JSON before forwarding.
        """
        await self._forward_socket_data(session_id, app_id, page_id, data)

    async def setup_inspector_socket(
        self, session_id: str, app_id: str, page_id: int, automatically_pause: bool = False
    ) -> None:
        """Set up a forwarding socket for an inspector session.

        :param session_id: The session identifier to associate with the socket.
        :param app_id: The target application identifier.
        :param page_id: The target page identifier.
        :param automatically_pause: Ask WebKit to pause the debuggable on its next statement once
            the frontend reports itself initialized (`Inspector.initialized`) - Safari's
            "Automatically Pause Connecting to JSContexts". Honoured by JSContexts, service
            workers and legacy WebViews; a WKWebView's page ignores it.
        """
        await self._forward_socket_setup(session_id, app_id, page_id, automatically_pause=automatically_pause)

    async def set_automatic_inspection_enabled(self, enabled: bool) -> None:
        """Ask `webinspectord` to offer this connection every debuggable an application creates,
        before the application gets to run it (see `AutomaticInspectionCandidate`).

        While any connection has this enabled, every application holds each new JSContext until
        the candidate is answered; subscribe with `subscribe_automatic_inspection` first, and
        switch it off again when done.

        :param enabled: Whether to receive candidates.
        """
        await self._send_message(
            "_rpc_forwardAutomaticInspectionConfiguration:", {"WIRAutomaticInspectionEnabledKey": enabled}
        )

    def subscribe_automatic_inspection(self) -> "asyncio.Queue[AutomaticInspectionCandidate]":
        """Receive automatic-inspection candidates as they are offered.

        A candidate is accepted by setting up an inspector socket for its page and completing the
        frontend handshake, or declined with `reject_automatic_inspection`. Candidates offered while
        nobody is subscribed are declined on the spot, so applications never wait on this client.

        :returns: A queue the candidates are published into; hand it back to
            `unsubscribe_automatic_inspection` when done.
        """
        queue: asyncio.Queue[AutomaticInspectionCandidate] = asyncio.Queue()
        self._candidate_subscribers.append(queue)
        return queue

    def unsubscribe_automatic_inspection(self, queue: "asyncio.Queue[AutomaticInspectionCandidate]") -> None:
        with contextlib.suppress(ValueError):
            self._candidate_subscribers.remove(queue)

    async def reject_automatic_inspection(self, candidate: AutomaticInspectionCandidate) -> None:
        """Decline a candidate, letting the application resume (or be offered to the next debugger).

        :param candidate: The candidate as published by `subscribe_automatic_inspection`.
        """
        await self._send_message(
            "_rpc_forwardAutomaticInspectionRejection:",
            {
                "WIRApplicationIdentifierKey": candidate.app_id,
                "WIRPageIdentifierKey": candidate.page_id,
                "WIRAutomaticInspectionSessionIdentifierKey": candidate.session_id,
            },
        )

    def subscribe_listings(self) -> "asyncio.Queue[str]":
        """Be told whenever an application's page listing arrives - `webinspectord` relays one on
        its own the moment a page opens, closes or navigates.

        :returns: A queue the identifier of the application whose listing changed is published
            into; hand it back to `unsubscribe_listings` when done.
        """
        queue: asyncio.Queue[str] = asyncio.Queue()
        self._listing_subscribers.append(queue)
        return queue

    def unsubscribe_listings(self, queue: "asyncio.Queue[str]") -> None:
        with contextlib.suppress(ValueError):
            self._listing_subscribers.remove(queue)

    async def teardown_inspector_socket(self, session_id: str, app_id: str, page_id: int):
        """Tear down a forwarding socket previously set up for an inspector session.

        Without this, webinspectord considers the session still active and ignores the next
        socket setup for the same page, so a future session never receives its target events.

        :param session_id: The session identifier the socket was associated with.
        :param app_id: The target application identifier.
        :param page_id: The target page identifier.
        """
        await self._forward_did_close(session_id, app_id, page_id)
        self.wir_events.pop(session_id, None)

    def session_events(self, session_id: str) -> deque[Any]:
        """The queue of events `webinspectord` forwarded to one session's socket.

        Events carry no id, so a consumer cannot tell its own from another's by content, and
        WebKit allows one inspector session per page but several across pages. `webinspectord`
        tags every forwarded message with the session it belongs to, so they are queued per
        session: concurrent sessions - two DevTools tabs, two JSContexts - would otherwise
        consume each other's events.

        :param session_id: The session identifier the socket was set up with.
        :returns: The session's queue (a deque, so consuming from the front is O(1)); consumers pop
            from it in place.
        """
        return self.wir_events.setdefault(session_id, deque())

    def find_page_id(self, page_id: str) -> tuple[Application, Page]:
        """Look up the application and page for a known page identifier.

        :param page_id: An identifier as built by `make_target_id`. A bare page identifier is also
            accepted, resolving to the first application reporting it - note that page identifiers
            are only unique per application (every JSContext debuggable is page 1 of its own
            process), so it cannot address them all.
        :returns: A tuple of the owning application and the matching page.
        :raises KeyError: No page with the given identifier is currently known.
        """
        app_id, _, page_key = page_id.rpartition(":")
        if page_key in self.application_pages.get(app_id, {}):
            return self.connected_application[app_id], self.application_pages[app_id][page_key]
        for app_id in self.application_pages:
            for page in self.application_pages[app_id]:
                if page == page_id:
                    return self.connected_application[app_id], self.application_pages[app_id][page_id]
        raise KeyError(f"Page with id {page_id} not found")

    async def flush_input(self, duration: Union[float, int] = 0):
        """Yield control for the given duration to let pending incoming messages be processed.

        :param duration: Seconds to sleep while the background receive task drains input.
        """
        return await asyncio.sleep(duration)

    async def _handle_recv(self, plist: dict[str, Any]):
        await self.receive_handlers[plist["__selector"]](plist["__argument"])

    async def _handle_report_current_state(self, arg: dict[str, Any]):
        self.state = arg.get("WIRAutomationAvailabilityKey", AutomationAvailability.UNKNOWN.value)

    async def _handle_report_connected_application_list(self, arg: dict[str, Any]):
        self.connected_application = {}
        for key, application in arg["WIRApplicationDictionaryKey"].items():
            self.connected_application[key] = Application.from_application_dictionary(application)

            # Immediately also query the application pages
            await self._forward_get_listing(self.connected_application[key].id_)

    async def _handle_report_connected_driver_list(self, arg: dict[str, Any]):
        pass

    async def _handle_application_sent_listing(self, arg: dict[str, Any]):
        app_id = arg["WIRApplicationIdentifierKey"]
        known: dict[str, Page] = self.application_pages.get(app_id, {})
        # A listing is the application's complete set of pages, not a delta: a page missing from it
        # has been closed. Merging one in without dropping those kept every tab ever opened in the
        # listing for the rest of the session. Pages that survive are updated in place - sessions
        # hold references to them.
        pages: dict[str, Page] = {}
        for id_, page in arg["WIRListingKey"].items():
            if id_ in known:
                known[id_].update(page)
                pages[id_] = known[id_]
            else:
                pages[id_] = Page.from_page_dictionary(page)
        self.application_pages[app_id] = pages
        for queue in self._listing_subscribers:
            queue.put_nowait(app_id)

    async def _handle_report_automatic_inspection_candidate(self, arg: dict[str, Any]) -> None:
        candidate = AutomaticInspectionCandidate(
            arg["WIRApplicationIdentifierKey"],
            arg["WIRPageIdentifierKey"],
            arg["WIRAutomaticInspectionSessionIdentifierKey"],
        )
        if not self._candidate_subscribers:
            # Nobody to take it: decline now rather than let the application wait out its timeout.
            await self.reject_automatic_inspection(candidate)
            return
        for queue in self._candidate_subscribers:
            queue.put_nowait(candidate)

    async def _handle_application_updated(self, arg: dict[str, Any]):
        app = Application.from_application_dictionary(arg)
        self.connected_application[app.id_] = app

    async def _handle_application_connected(self, arg: dict[str, Any]):
        app = Application.from_application_dictionary(arg)
        self.connected_application[app.id_] = app

    async def _handle_application_sent_data(self, arg: dict[str, Any]):
        response = json.loads(arg["WIRMessageDataKey"])
        trace = getattr(self, "trace", None)
        if trace is not None:
            trace("device->bridge", arg.get("WIRDestinationKey", ""), response)

        if "id" in response:
            self.wir_message_results[response["id"]] = response
        else:
            self.session_events(arg.get("WIRDestinationKey", "")).append(response)

    async def _handle_application_disconnected(self, arg: dict[str, Any]):
        self.connected_application.pop(arg["WIRApplicationIdentifierKey"], None)
        self.application_pages.pop(arg["WIRApplicationIdentifierKey"], None)

    async def _report_identifier(self):
        await self._send_message("_rpc_reportIdentifier:")

    async def _forward_get_listing(self, app_id: str):
        self.logger.debug(f"Listing app with id {app_id}")
        await self._send_message("_rpc_forwardGetListing:", {"WIRApplicationIdentifierKey": app_id})

    async def _request_application_launch(self, bundle: str):
        await self._send_message("_rpc_requestApplicationLaunch:", {"WIRApplicationBundleIdentifierKey": bundle})

    async def _get_connected_applications(self) -> None:
        await self._send_message("_rpc_getConnectedApplications:", {})

    async def _forward_automation_session_request(self, session_id: str, app_id: str):
        await self._send_message(
            "_rpc_forwardAutomationSessionRequest:",
            {
                "WIRApplicationIdentifierKey": app_id,
                "WIRSessionCapabilitiesKey": {
                    "org.webkit.webdriver.webrtc.allow-insecure-media-capture": True,
                    "org.webkit.webdriver.webrtc.suppress-ice-candidate-filtering": False,
                },
                "WIRSessionIdentifierKey": session_id,
            },
        )

    async def _forward_socket_setup(
        self, session_id: str, app_id: str, page_id: int, automatically_pause: bool = False
    ) -> None:
        await self._send_message(
            "_rpc_forwardSocketSetup:",
            {
                "WIRApplicationIdentifierKey": app_id,
                "WIRPageIdentifierKey": page_id,
                "WIRSenderKey": session_id,
                "WIRMessageDataTypeChunkSupportedKey": 0,
                # Read by inspection targets only; an automation target's setup ignores it.
                "WIRAutomaticallyPause": automatically_pause,
            },
        )

    async def _forward_socket_data(self, session_id: str, app_id: str, page_id: int, data: dict[str, Any]):
        trace = getattr(self, "trace", None)
        if trace is not None:
            trace("bridge->device", session_id, data)
        await self._send_message(
            "_rpc_forwardSocketData:",
            {
                "WIRApplicationIdentifierKey": app_id,
                "WIRPageIdentifierKey": page_id,
                "WIRSessionIdentifierKey": session_id,
                "WIRSenderKey": session_id,
                "WIRSocketDataKey": json.dumps(data).encode(),
            },
        )

    async def _forward_did_close(self, session_id: str, app_id: str, page_id: int):
        await self._send_message(
            "_rpc_forwardDidClose:",
            {
                "WIRApplicationIdentifierKey": app_id,
                "WIRPageIdentifierKey": page_id,
                "WIRSenderKey": session_id,
            },
        )

    async def indicate_web_view(self, app: Application, page: Page, enable: bool) -> None:
        """Highlight a web page's view on the device screen (a translucent overlay, as Safari's
        Develop menu does while hovering a page), or clear the highlight.

        :param app: The application owning the page.
        :param page: The web page to highlight. JSContexts have nothing to highlight.
        :param enable: Whether to show or clear the highlight.
        """
        await self._forward_indicate_web_view(app.id_, page.id_, enable)

    async def _forward_indicate_web_view(self, app_id: str, page_id: int, enable: bool):
        await self._send_message(
            "_rpc_forwardIndicateWebView:",
            {
                "WIRApplicationIdentifierKey": app_id,
                "WIRPageIdentifierKey": page_id,
                "WIRIndicateEnabledKey": enable,
            },
        )

    async def _send_message(self, selector: str, args: Optional[dict[str, Any]] = None):
        if args is None:
            args = {}
        args["WIRConnectionIdentifierKey"] = self.connection_id
        # Never let a send establish the connection. While reconnecting, self._service is None and
        # self.service would lazily run the handshake - a second reader on the socket the reconnect
        # is already reading, which asyncio rejects ("readexactly() called while another coroutine
        # is already waiting"). A send with no live service (lost, or mid-reconnect) is a no-op.
        if self._connection_lost or self._service is None:
            return
        try:
            await self._service.send_plist({"__selector": selector, "__argument": args})
        except (ConnectionError, ConnectionTerminatedError, OSError, EOFError) as error:
            self._note_connection_lost(error)

    async def _wait_for_page(self, session_id: str) -> Page:
        while True:
            for app in self.application_pages.values():
                for page in app.values():
                    if page.type_ == WirTypes.AUTOMATION and page.automation_session_id == session_id:
                        return page
            await asyncio.sleep(0)

    async def _wait_for_application(self, bundle: str = "", app_id: str = "") -> Application:
        while True:
            for app in self.connected_application.values():
                if bundle and app.bundle == bundle:
                    return app
                if app_id and app.id_ == app_id:
                    return app
            await asyncio.sleep(0)
