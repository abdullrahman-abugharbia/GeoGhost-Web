﻿GeoGhost for Windows
====================

Moves the location of an iPhone that is plugged into this PC by USB. Every app
on the phone reads the position you set.

BEFORE YOU START
  1. Install Apple Mobile Device Support. It comes with iTunes, or with the
     "Apple Devices" app from the Microsoft Store. Without it GeoGhost cannot
     see the phone and says so.
  2. Plug the iPhone in, unlock it, and tap Trust if it asks.

RUNNING IT
  Run GeoGhost.exe, pick the phone, type the latitude and longitude, press
  Start. The position holds while the app stays open and the phone stays
  plugged in. Press Stop, unplug the phone or restart it, and the phone goes
  back to its real position.

GOOD TO KNOW
  - Works with iOS 16 and below. iOS 17 and newer are recognised but not
    supported yet.
  - Keep the agent folder next to GeoGhost.exe. The app looks for it there.
  - Unpack the whole folder somewhere first. Running it from inside the zip
    does not work.
  - Windows SmartScreen may warn the first time, because the app is not
    signed yet. Choose More info, then Run anyway.

For the Android app, the activation code or anything else, talk to us on the
website.


GeoGhost لويندوز
=================

يغيّر موقع آيفون موصول بالكمبيوتر عبر كابل USB، فتقرأ كل التطبيقات على
الهاتف الموقع الذي تختاره.

قبل البدء
  ١. ثبّت Apple Mobile Device Support، وهو يأتي مع iTunes أو مع تطبيق
     Apple Devices من متجر مايكروسوفت. بدونه لن يرى GeoGhost الهاتف.
  ٢. وصّل الآيفون، وافتح قفله، واضغط «وثوق» إن سألك.

التشغيل
  شغّل GeoGhost.exe، اختر الهاتف، اكتب خط العرض وخط الطول، ثم اضغط Start.
  يبقى الموقع ثابتًا ما دام التطبيق مفتوحًا والهاتف موصولًا. وعند Stop أو فصل
  الهاتف أو إعادة تشغيله يعود إلى موقعه الحقيقي.

ملاحظات
  - يعمل مع iOS 16 فأقل. أما iOS 17 فما فوق فيُعرَف ولكنه غير مدعوم بعد.
  - أبقِ مجلد agent بجانب GeoGhost.exe، فالتطبيق يبحث عنه هناك.
  - فُكّ المجلد كاملًا أولًا. التشغيل من داخل ملف الضغط لا يعمل.
  - قد ينبّهك Windows SmartScreen في أول مرة لأن التطبيق غير موقّع بعد.
    اختر More info ثم Run anyway.

للحصول على تطبيق أندرويد أو رمز التفعيل أو أي شيء آخر، تحدّث معنا من الموقع.
