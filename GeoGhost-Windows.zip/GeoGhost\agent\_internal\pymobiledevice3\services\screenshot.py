from typing import Any, cast

from pymobiledevice3.exceptions import ProtocolError
from pymobiledevice3.lockdown_service_provider import LockdownServiceProvider
from pymobiledevice3.services.lockdown_service import LockdownService


class ScreenshotService(LockdownService):
    """
    Capture a screenshot of the device's screen via the ``com.apple.mobile.screenshotr`` service.

    The service speaks the DeviceLink protocol and requires a developer image (developer mode) to be
    mounted on the device.
    """

    SERVICE_NAME = "com.apple.mobile.screenshotr"

    def __init__(self, lockdown: LockdownServiceProvider) -> None:
        super().__init__(lockdown, self.SERVICE_NAME, is_developer_service=True)
        self._did_handshake = False

    async def _handshake(self) -> None:
        if self._did_handshake:
            return
        # DeviceLink messages are list-rooted, unlike the dictionary-rooted request/response
        # services; narrow the received plist accordingly.
        dl_message_version_exchange = cast(list[Any], await self.service.recv_plist())
        version_major = dl_message_version_exchange[1]
        await self.service.send_plist(["DLMessageVersionExchange", "DLVersionsOk", version_major])
        dl_message_device_ready = cast(list[Any], await self.service.recv_plist())
        if dl_message_device_ready[0] != "DLMessageDeviceReady":
            raise ProtocolError("The screenshot service did not report it was ready.")
        self._did_handshake = True

    async def take_screenshot(self) -> bytes:
        """
        Capture the current screen contents.

        Performs the DeviceLink handshake on first use, then requests a single screenshot.

        :returns: Raw image data as returned by the device (typically PNG or TIFF).
        :raises PyMobileDevice3Exception: If the service returns an unexpected response.
        """
        await self._handshake()
        await self.service.send_plist(["DLMessageProcessMessage", {"MessageType": "ScreenShotRequest"}])
        response = cast(list[Any], await self.service.recv_plist())

        assert len(response) == 2
        assert response[0] == "DLMessageProcessMessage"

        if response[1].get("MessageType") == "ScreenShotReply":
            return response[1]["ScreenShotData"]

        raise ProtocolError(f"The screenshot service sent an unexpected reply: {response}")
